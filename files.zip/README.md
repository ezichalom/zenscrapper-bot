# 🤖 ZenMarket Bot — Monitor de Produtos

Bot em Python que monitora o [ZenMarket.jp](https://zenmarket.jp/pt/) e envia notificações no **Telegram** toda vez que um novo produto com suas palavras-chave é anunciado.

---

## 📦 Estrutura do Projeto

```
zenmarket_bot/
├── bot.py           ← Ponto de entrada (execute este)
├── config.py        ← ⚙️  SUAS CONFIGURAÇÕES (edite aqui)
├── scraper.py       ← Raspagem do ZenMarket
├── notifier.py      ← Envio de mensagens no Telegram
├── storage.py       ← Banco de dados SQLite (evita duplicatas)
├── get_chat_id.py   ← Script auxiliar para descobrir seu Chat ID
└── requirements.txt ← Dependências Python
```

---

## 🚀 Instalação Passo a Passo

### 1. Pré-requisitos

- **Python 3.8+** instalado ([baixar aqui](https://www.python.org/downloads/))
- Conta no Telegram

### 2. Crie um Bot no Telegram

1. Abra o Telegram e pesquise por **@BotFather**
2. Envie o comando `/newbot`
3. Escolha um **nome** para o bot (ex: `Meu ZenMarket Bot`)
4. Escolha um **username** (precisa terminar com `bot`, ex: `zenmarket_monitor_bot`)
5. O BotFather vai te enviar um **TOKEN** — guarde ele!

### 3. Instale as Dependências

```bash
# Crie um ambiente virtual (recomendado)
python -m venv venv

# Ative o ambiente virtual
# No Windows:
venv\Scripts\activate
# No Mac/Linux:
source venv/bin/activate

# Instale as dependências
pip install -r requirements.txt
```

### 4. Configure o Bot

Abra o arquivo `config.py` e preencha:

```python
TELEGRAM_BOT_TOKEN = "1234567890:ABCdef..."   # Token do BotFather
TELEGRAM_CHAT_ID   = "987654321"              # Veja próximo passo

KEYWORDS = [
    "pokemon card",
    "gundam",
    "one piece",
]

PLATFORMS = ["yahoo", "mercari"]   # ou adicione "rakuten"

CHECK_INTERVAL_MINUTES = 3         # Verifica a cada 3 minutos
```

### 5. Descubra seu Chat ID

1. Abra o Telegram e mande qualquer mensagem para o **seu bot** que acabou de criar
2. Execute o script auxiliar:

```bash
python get_chat_id.py
```

3. Copie o número exibido e cole em `TELEGRAM_CHAT_ID` no `config.py`

### 6. Rode o Bot!

```bash
python bot.py
```

Se tudo estiver certo, você receberá uma mensagem no Telegram confirmando que o bot iniciou. ✅

---

## ⚙️ Configurações Disponíveis (`config.py`)

| Configuração | Descrição | Padrão |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | Token do seu bot | (obrigatório) |
| `TELEGRAM_CHAT_ID` | ID do chat de destino | (obrigatório) |
| `KEYWORDS` | Lista de palavras-chave | (obrigatório) |
| `PLATFORMS` | Plataformas: `yahoo`, `mercari`, `rakuten` | `["yahoo", "mercari"]` |
| `CHECK_INTERVAL_MINUTES` | Intervalo de verificação em minutos | `3` |
| `MIN_PRICE_JPY` | Preço mínimo em ienes (0 = sem limite) | `0` |
| `MAX_PRICE_JPY` | Preço máximo em ienes (0 = sem limite) | `0` |
| `MAX_RESULTS_PER_SEARCH` | Máximo de resultados por busca | `30` |
| `HEARTBEAT_HOURS` | Status automático a cada X horas | `6` |

---

## 💡 Dicas de Uso

### Palavras-chave em japonês
Para resultados mais precisos, use termos em japonês:
```python
KEYWORDS = [
    "ポケモン",     # Pokemon
    "ガンダム",     # Gundam
    "フィギュア",   # Figure
    "ドラゴンボール", # Dragon Ball
]
```

### Filtro de preço
Para filtrar apenas produtos até ¥5.000:
```python
MIN_PRICE_JPY = 0
MAX_PRICE_JPY = 5000
```

### Monitorar só o Yahoo Auctions
```python
PLATFORMS = ["yahoo"]
```

---

## 🖥️ Rodar 24/7 (Servidor)

Para o bot funcionar continuamente sem precisar deixar seu computador ligado, use um serviço gratuito:

### Opção 1: Railway (recomendado, gratuito)
1. Crie conta em [railway.app](https://railway.app)
2. Faça upload do projeto (ou conecte ao GitHub)
3. Configure as variáveis de ambiente:
   - `TELEGRAM_BOT_TOKEN`
   - `TELEGRAM_CHAT_ID`

### Opção 2: Render
1. Crie conta em [render.com](https://render.com)
2. Crie um **Background Worker**
3. Configure o comando de start: `python bot.py`

### Opção 3: VPS (DigitalOcean, Hetzner, etc.)
```bash
# Instale screen para manter rodando após fechar o SSH
screen -S zenbot
python bot.py
# Ctrl+A, D para desanexar
```

---

## 📱 Exemplo de Notificação

```
🔔 NOVO PRODUTO ENCONTRADO!

📦 Pokemon Card Charizard VMAX Secret Rare

💴 Preço: ¥ 3,500
🔍 Palavra-chave: pokemon card
🏪 Plataforma: 🏷️ Yahoo Auctions

🔗 Ver no ZenMarket →
```

---

## ❗ Solução de Problemas

| Problema | Solução |
|---|---|
| "TOKEN não configurado" | Preencha `TELEGRAM_BOT_TOKEN` no `config.py` |
| Bot não envia mensagens | Verifique se mandou uma mensagem pro bot antes de rodar `get_chat_id.py` |
| "0 produtos encontrados" | O ZenMarket pode estar bloqueando; tente aumentar o intervalo ou usar palavras em japonês |
| Bot para de funcionar | Verifique o `zenmarket_bot.log` para ver o erro |

---

## 📄 Licença

Uso pessoal. Respeite os Termos de Serviço do ZenMarket.
