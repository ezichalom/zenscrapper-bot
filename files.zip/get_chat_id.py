"""
get_chat_id.py — Script auxiliar para descobrir seu Chat ID no Telegram

COMO USAR:
  1. Coloque seu TELEGRAM_BOT_TOKEN no config.py
  2. Abra o Telegram e mande qualquer mensagem para o seu bot
  3. Execute: python get_chat_id.py
  4. Copie o Chat ID exibido e cole em TELEGRAM_CHAT_ID no config.py
"""

import requests
from config import TELEGRAM_BOT_TOKEN


def get_updates():
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/getUpdates"
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()

        if not data.get("ok"):
            print(f"❌ Erro da API: {data.get('description')}")
            print("Verifique se o TELEGRAM_BOT_TOKEN está correto no config.py")
            return

        updates = data.get("result", [])
        if not updates:
            print("⚠️  Nenhuma mensagem encontrada.")
            print("👉 Abra o Telegram, mande qualquer mensagem para o seu bot e rode este script novamente.")
            return

        print("✅ Mensagens encontradas!\n")
        seen_chats = set()
        for update in updates:
            msg = update.get("message") or update.get("channel_post")
            if not msg:
                continue
            chat = msg.get("chat", {})
            chat_id = chat.get("id")
            if chat_id in seen_chats:
                continue
            seen_chats.add(chat_id)

            chat_type  = chat.get("type", "?")
            chat_title = chat.get("title") or chat.get("username") or chat.get("first_name", "?")
            sender     = msg.get("from", {}).get("username", "?")

            print(f"  Chat ID   : {chat_id}")
            print(f"  Tipo      : {chat_type}")
            print(f"  Nome/Título: {chat_title}")
            print(f"  Remetente : @{sender}")
            print()

        print("👉 Copie o Chat ID acima e cole em TELEGRAM_CHAT_ID no config.py")

    except requests.exceptions.RequestException as e:
        print(f"❌ Erro de rede: {e}")


if __name__ == "__main__":
    if TELEGRAM_BOT_TOKEN == "SEU_TOKEN_AQUI":
        print("❌ Configure o TELEGRAM_BOT_TOKEN no config.py antes de continuar.")
    else:
        get_updates()
